package com.example.white_rabit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
